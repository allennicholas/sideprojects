package groupfile_0302;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.lang.Math;

public class groupFile_0302 {
   public static void main(String[] args){
      
      String name;                // To hold a name
      double Hours;               // Hours worked
      double payRate;             // Hourly pay rate
      double otPay;               // Overtime pay rate
      double grossPay;            // Gross pay
      double overtime;            // Overtime
      double fedTax;              // Federal tax rate
      double fedTaxAmount;        // Federal tax amount
      double ficaTax;             // FICA tax rate
      double ficaTaxAmount;       // FICA tax amount
      double stateTax;            // State tax rate
      double stateTaxAmount;      // State tax amount
      double localTax;            // Local tax rate
      double localTaxAmount;      // Local tax amount
      double afterDeductions;     // Total after deductions
      
      Hours = 0.00;
      payRate = 0.00;
      otPay = 0.00;
      grossPay = 0.00;
      overtime = 0.00;
      fedTax = 00.15;
      fedTaxAmount = 0.00;
      ficaTax = 0.0765;
      ficaTaxAmount = 0.00;
      stateTax = 0.0550;
      stateTaxAmount = 0.00;
      localTax = 0.00;
      localTaxAmount = 0.00;
      afterDeductions = 0.00;
      
      Scanner keyboard = new Scanner(System.in);
      
      name = JOptionPane.showInputDialog(null, "What's your name?");
      //JOptionPane.showMessageDialog(null, "Good day " + name);
      
      //System.out.print("How many hours did you work this week? ");
      //Hours = keyboard.nextDouble();
      
      Hours = Integer.parseInt(JOptionPane.showInputDialog(null, "How many hours did you work?"));
      //JOptionPane.showMessageDialog(null, "You worked " + Hours + " hours this week!!!");
      
      //System.out.print("What is your hourly pay rate? ");
      //payRate = keyboard.nextDouble();
      
      payRate = Integer.parseInt(JOptionPane.showInputDialog(null, "What is your hourly rate?"));
      //JOptionPane.showMessageDialog(null, "You make $"  + payRate + " per hour");
      
      //System.out.print("What is your local tax rate? ");
      //localTax = keyboard.nextDouble();
      
      localTax = Integer.parseInt(JOptionPane.showInputDialog(null, "What is your local tax rate?"));
      if (localTax < 0);
      else if (localTax > 0)
          localTax = Math.pow((localTax), -1);
          
          //JOptionPane.showMessageDialog(null, "Your local tax rate is " + localTax);
      
      if (Hours > 40)
          overtime = (Hours  - 40);
      else if (Hours < 40)
          overtime = 0;
      
      otPay = (payRate * 1.5) * overtime;
      grossPay = (Hours * payRate) + otPay;
      fedTaxAmount = (grossPay * fedTax);
      ficaTaxAmount = (grossPay * ficaTax);
      stateTaxAmount = (grossPay * stateTax);
      localTaxAmount = (grossPay * localTax);
      
      afterDeductions = (grossPay - fedTaxAmount - ficaTaxAmount - stateTaxAmount - localTaxAmount);
      
      
      //System.out.println("Hello, " + name);
      //System.out.println("Hours worked: \t\t\t" + Hours);
      //System.out.printf("Pay rate per hour: \t\t$%,.2f%n", payRate);
      //System.out.println("Hours over 40 worked: \t\t" + overtime);
      //System.out.printf("Overtime pay: \t\t\t$%,.2f%n", otPay);
      //System.out.printf("Your gross pay is $\t\t$%,.2f%n", grossPay);
      //System.out.printf("Federal tax amount: \t\t$%,.2f%n", fedTaxAmount);
      //System.out.printf("FICA tax withheld: \t\t$%,.2f%n", ficaTaxAmount);
      //System.out.printf("State tax withheld \t\t$%,.2f%n", stateTaxAmount);
      
      //if (localTax == 0);
      //else if (localTax > 0)
      //    System.out.printf("Local tax withheld \t\t$%,.2f%n", localTaxAmount);
      
      //System.out.printf("Your bring home pay is: \t$%,.2f%n", afterDeductions);
      //JOptionPane.showMessageDialog(null, "You make $" + afterDeductions + " after taxes!");
      JOptionPane.showMessageDialog(null, "Hello " + name + ". \nYou worked " + Hours + " hours this week. \nYou make $" + String.format("%,.2f", payRate) + " per hour. \nTotal paycheck after taxes is $" + String.format("%,.2f", afterDeductions));
   }
}
